﻿
███ ████ ████ █   █ ███ █   █ ████  ██  ███  ████ ████ █████
 █     █ █  █ ██ ██  █  ██  █ █    █  █ █  █ █  █ █      █
 █     █ ████ █ █ █  █  █ █ █ ████ █    ███  ████ ████   █
 █  █  █ █  █ █   █  █  █  ██ █    █  █ █  █ █  █ █      █
███  ██  █  █ █   █ ███ █   █ ████  ██  █  █ █  █ █      █

This work was created and is copyrighted by IJAMinecraft.
License: https://ijaminecraft.com/copyright

Visit IJAMinecraft here:
Website: ijaminecraft.com
YouTube: youtube.com/user/IJAMinecraft
